import React, { Component } from "react";

class Posts extends Component {
  render() {
    return <div></div>;
  }
}
export default Posts;
